'''Otwarcie pliku Pary.txt i wpisanie znajdujących się w nim liczb w tabeli, zamknięcie pliku'''
f = open("Pary.txt", 'r')
for line in f:
        l = (line.strip().split())
f.close()
'''NWW i NWD'''
def nwd(a, b):
    a = int(a)
    b = int(b)
    if b > 0:
        return nwd(b, a%b)
    return a
def nww(a, b):
    a = int(a)
    b = int(b)
    return a*b//nwd(a, b)
'''Przejście po liście'''
for i in range(len(l)-1):
    NWP = nwd(l[i], l[i+1])
    NWW = nww(l[i], l[i+1])
    g = open("Pary.out.txt", "a")
    NWW = str(NWW)
    NWP = str(NWP)
    g.write(l[i]+", "+ l[i+1]+", "+str(NWW)+", "+str(NWP)+"\n")
    g.write("Kolejny wynik\n")
